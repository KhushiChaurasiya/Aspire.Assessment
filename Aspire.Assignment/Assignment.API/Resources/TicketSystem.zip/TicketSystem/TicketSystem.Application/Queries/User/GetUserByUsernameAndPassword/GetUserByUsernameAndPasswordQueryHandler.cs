﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediatR;
using TicketSystem.Application;
using TicketSystem.Domain.Entity;
using TicketSystem.InfraStructure;
using TicketSystem.InfraStructure.Service;

namespace TicketSystem.Application
{
    public class GetUserByUsernameAndPasswordQueryHandler : IRequestHandler<GetUserByUsernameAndPasswordQuery, IBaseResponse>
    {
        IUserService context;
        IBaseResponse responseModel;
        public GetUserByUsernameAndPasswordQueryHandler(IUserService context, IBaseResponse responseModel)
        {
            this.context = context;
            this.responseModel = responseModel;
        }

        public Task<IBaseResponse> Handle(GetUserByUsernameAndPasswordQuery request, CancellationToken cancellationToken)
        {
            responseModel.IsSuccess = true;
            responseModel.Data = context.GetUserByUsernameAndpassword(request.Username, request.Password);
            return Task.FromResult(responseModel);
        }
    }
}
