﻿namespace TicketSystem.Application
{
    internal class GetTicketQuery
    {
    }
}
