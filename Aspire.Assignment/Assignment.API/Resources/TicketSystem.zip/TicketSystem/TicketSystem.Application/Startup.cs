﻿using MediatR;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using TicketSystem.Application.Common;
using FluentValidation;
namespace TicketSystem.Application
{
    public static class Startup
    {
        public static IServiceCollection AddApplicationAssembley(this IServiceCollection services)
        {
            services.AddMediatR(
                        typeof(Startup)   
            );

            services.AddScoped<IBaseResponse, BaseResponse>();

            services.AddScoped(typeof(IPipelineBehavior<,>), typeof(ValidationBehavior<,>));

            return services;
        }
    }
}
