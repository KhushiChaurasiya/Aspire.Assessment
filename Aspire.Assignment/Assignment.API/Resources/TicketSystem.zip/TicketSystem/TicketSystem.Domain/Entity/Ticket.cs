﻿using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketSystem.Domain.Enum;

namespace TicketSystem.Domain.Entity
{
    public class Ticket
    {
        public ObjectId Id { get; set; }
        public string TicketTitle { get; set; }
        public string TicketDescription { get; set; }
        public DateTime CreatedDate { get; set; }
        public User User { get; set; }
        public TicketStatus MyProperty { get; set; }
    }
}
