﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediatR;
using TicketSystem.Application;
using TicketSystem.Domain.Entity;
using TicketSystem.InfraStructure.Service;

namespace TicketSystem.Application
{
    public class AddRoleCommandHandler : IRequestHandler<AddRoleCommand, IBaseResponse>
    {
        private readonly IRoleService context;
        private readonly IBaseResponse responseModel;
        public AddRoleCommandHandler(IRoleService context, IBaseResponse responseModel)
        {
            this.context = context;
            this.responseModel = responseModel;
        }
        public Task<IBaseResponse> Handle(AddRoleCommand request, CancellationToken cancellationToken)
        {
            context.AddRole(new Domain.Entity.Role() { 
                RoleName = request.RoleName 
            });
            responseModel.IsSuccess = true;
            return Task.FromResult(responseModel);
        }
    }
}
