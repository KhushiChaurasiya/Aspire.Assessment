
    // $('.collapse').collapse();
    function Getfooter() {
        $('#footer_body').on('show', function () {
          $("html, body").animate({ scrollTop: $(document).height() }, "slow");
        });
      };