﻿using MediatR;
using TicketSystem.InfraStructure.Service;
using Newtonsoft.Json;
using TicketSystem.Domain.Entity;

namespace TicketSystem.Application
{
    public class GetRoleQueryHandler : IRequestHandler<GetRoleQuery, IBaseResponse>
    {
        IRoleService context;
        IBaseResponse responseModel;
        public GetRoleQueryHandler(IRoleService context, IBaseResponse responseModel)
        {
            this.responseModel = responseModel;
            this.context = context;
        }
        public Task<IBaseResponse> Handle(GetRoleQuery request, CancellationToken cancellationToken)
        {
            responseModel.Data = context.GetRolles();
            responseModel.IsSuccess = true;
            return Task.FromResult(responseModel);
        }
    }
}
