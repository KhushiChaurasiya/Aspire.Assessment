﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketSystem.Application;
using TicketSystem.InfraStructure.Service;
using TicketSystem.Domain.Entity;
namespace TicketSystem.Application
{
    public class AddUserCommandHandler : IRequestHandler<AddUserCommand, BaseResponse>
    {
        IUserService context;
        public AddUserCommandHandler(IUserService context)
        {
            this.context = context;
        }

        public Task<BaseResponse> Handle(AddUserCommand request, CancellationToken cancellationToken)
        {
            User user = new User() { 
                Email=request.Email,
                Name=request.Name,
                Password=request.Password,
            };
            return null;
            
        }
    }
}
