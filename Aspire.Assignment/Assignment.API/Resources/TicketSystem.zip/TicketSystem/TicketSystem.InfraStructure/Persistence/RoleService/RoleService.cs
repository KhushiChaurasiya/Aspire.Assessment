﻿using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketSystem.Domain.Entity;

namespace TicketSystem.InfraStructure.Service
{
    public class RoleService : IRoleService
    {

        private readonly IMongoCollection<Role> _roleCollection;

        public RoleService(IOptions<TicketSystemDataBaseDetails> optionsDatabaseSettings)
        {
            var mongoClient = new MongoClient(optionsDatabaseSettings.Value.ConnectionString);
            var mongoDatabase = mongoClient.GetDatabase(optionsDatabaseSettings.Value.DatabaseName);
            _roleCollection = mongoDatabase.GetCollection<Role>(optionsDatabaseSettings.Value.RoleCollectionName);
        }
        public async Task<List<Role>> GetRolles()
        {
            return await _roleCollection.Find(_ => true).ToListAsync();
        }

        public async Task AddRole(Role role)
        {
            await _roleCollection.InsertOneAsync(role);
        }

        public async Task DeleteRole(ObjectId id)
        {
            await _roleCollection.DeleteOneAsync(x => x.Id == id);
        }

        public async Task UpdateRole(ObjectId Id, Role role)
        {
            await _roleCollection.ReplaceOneAsync(x => x.Id == Id, role);
        }

    }
}
