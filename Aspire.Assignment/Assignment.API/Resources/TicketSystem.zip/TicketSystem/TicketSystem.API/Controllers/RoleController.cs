﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TicketSystem.Application;
using TicketSystem.Domain.Entity;

namespace TicketSystem.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoleController : Controller
    {

        IMediator mediator;
        public RoleController(IMediator mediator)
        {
            this.mediator = mediator;
        }
        [HttpGet]
        public async Task<IBaseResponse> GetUser()
        {
            return await mediator.Send(new GetRoleQuery());
        }
        [HttpPost]
        public async Task<IBaseResponse> AddUser([FromBody] AddRoleCommand user)
        {
            return await mediator.Send(user);
        }
    }
}
