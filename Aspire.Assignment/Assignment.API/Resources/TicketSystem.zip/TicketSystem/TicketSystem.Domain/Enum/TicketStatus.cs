﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketSystem.Domain.Enum
{
    public enum TicketStatus
    {
        New=0,
        InProgress=1,
        Approved=2,
        Rejected=3,
        Resolved=4,
        Closed=5
    }
}
