﻿using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketSystem.Domain.Entity
{
    

    public class User
    {
        public ObjectId Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public Role role { get; set; } = new Role();
        public ICollection<Ticket> Tickets { get; set; }
        public User()
        {

        }
        public User(string Name, string Email,string Password,long roleid)
        {
            this.Name = Name;
            this.Email = Email;
            this.Password = Password;
        }
    }
}
