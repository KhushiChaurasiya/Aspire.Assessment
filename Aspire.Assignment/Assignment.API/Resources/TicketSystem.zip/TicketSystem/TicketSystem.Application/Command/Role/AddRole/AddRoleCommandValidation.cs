﻿using FluentValidation;

namespace TicketSystem.Application
{
    public class AddRoleCommandValidation: AbstractValidator<AddRoleCommand>
    {
        public AddRoleCommandValidation()
        {
            RuleFor(x=>x.RoleName).NotEmpty().WithMessage("Rolename required.")
                .NotNull().WithMessage("Rolename required.");
        }
    }
}
