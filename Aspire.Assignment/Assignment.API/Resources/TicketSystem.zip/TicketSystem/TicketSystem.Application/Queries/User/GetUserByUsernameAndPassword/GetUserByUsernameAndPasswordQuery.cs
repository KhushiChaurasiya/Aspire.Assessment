﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediatR;
using TicketSystem.Application;
using TicketSystem.Domain.Entity;

namespace TicketSystem.Application
{
    public class GetUserByUsernameAndPasswordQuery:IRequest<IBaseResponse>
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
