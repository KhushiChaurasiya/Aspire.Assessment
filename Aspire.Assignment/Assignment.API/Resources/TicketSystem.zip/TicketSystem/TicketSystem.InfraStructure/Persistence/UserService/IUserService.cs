﻿using TicketSystem.Domain.Entity;

namespace TicketSystem.InfraStructure.Service
{
    public interface IUserService
    {
        Task<User> GetUserByUsernameAndpassword(string username, string password);
    }
}