﻿namespace TicketSystem.Application
{
    public interface IBaseResponse
    {
        object Data { get; set; }
        bool IsSuccess { get; set; }
    }
}