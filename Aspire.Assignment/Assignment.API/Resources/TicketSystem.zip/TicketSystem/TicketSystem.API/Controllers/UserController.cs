﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TicketSystem.Application;
using TicketSystem.Domain.Entity;
using TicketSystem.InfraStructure.Service;

namespace TicketSystem.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        IMediator mediator;
        public UserController(IMediator mediator)
        {
            this.mediator = mediator;
        }
        [HttpPost]
        public async Task<BaseResponse> AddUser([FromBody]AddUserCommand user)
        {
            return await mediator.Send(user);
        }
    }
}
