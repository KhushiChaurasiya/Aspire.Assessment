﻿using Microsoft.AspNetCore.Mvc;
using TicketSystem.Application;
using MediatR;
using TicketSystem.Domain.Entity;

namespace TicketSystem.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        readonly IMediator mediator;
        public LoginController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpPost]
        public async Task<IBaseResponse> login([FromBody] GetUserByUsernameAndPasswordQuery data)
        {
            return await mediator.Send(data);
        }
    }
}
