﻿using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketSystem.InfraStructure.Service;
using TicketSystem.Domain.Entity;
using TicketSystem.Application;

namespace TicketSystem.XUnitTest.Mocks.Role.AddRole
{
    public static class AddRoleCommandTestSetup
    {
        public static Mock<IRoleService> GetRoleRepository()
        {
            var mockRepo = new Mock<IRoleService>();

            mockRepo.Setup(r => r.AddRole(It.IsAny<Domain.Entity.Role>()));
            return mockRepo;
        }
        public static Mock<IBaseResponse> GetBaseResponseRepository()
        {
            var mockRepo = new Mock<IBaseResponse>();

            return mockRepo;
        }
    }

    public class nme
    {
        
        public string Name { get; set; }
        public int age { get; set; }
    }
}
