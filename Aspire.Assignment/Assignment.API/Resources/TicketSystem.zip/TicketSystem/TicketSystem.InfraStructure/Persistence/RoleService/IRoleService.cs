﻿using MongoDB.Bson;
using TicketSystem.Domain.Entity;

namespace TicketSystem.InfraStructure.Service
{
    public interface IRoleService
    {
        Task AddRole(Role role);
        Task DeleteRole(ObjectId id);
        Task<List<Role>> GetRolles();
        Task UpdateRole(ObjectId Id, Role role);
    }
}