﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketSystem.Application;

namespace TicketSystem.XUnitTest.Mocks.Role.AddRole
{
    
    public class AddRoleCommandTest
    {
        
        [Fact]
        public async Task AddRoleCommandHandlerTest()
        {
            var command = new AddRoleCommand()
            {
               RoleName="Admin"
            };
            var mokeRoleService=AddRoleCommandTestSetup.GetRoleRepository();
            var mokeBaseResponse = AddRoleCommandTestSetup.GetBaseResponseRepository();
            var _handler = new AddRoleCommandHandler(mokeRoleService.Object, mokeBaseResponse.Object);
            var result= await _handler.Handle(command, CancellationToken.None).Result;
            Assert.Equal(result.IsSuccess, true);
        }
    }
}
