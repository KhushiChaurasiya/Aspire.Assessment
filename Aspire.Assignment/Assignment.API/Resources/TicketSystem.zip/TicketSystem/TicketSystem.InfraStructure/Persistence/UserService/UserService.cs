﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketSystem.Domain.Entity;
using Microsoft.Extensions.Options;


namespace TicketSystem.InfraStructure.Service
{
    public class UserService : IUserService
    {
        private readonly IMongoCollection<User> _userCollection;
        public UserService(IOptions<TicketSystemDataBaseDetails> _TicketSystemDatabaseSettings)
        {
            var mongoClient = new MongoClient(
          _TicketSystemDatabaseSettings.Value.ConnectionString);

            var mongoDatabase = mongoClient.GetDatabase(
                _TicketSystemDatabaseSettings.Value.DatabaseName);

            _userCollection = mongoDatabase.GetCollection<User>(
                _TicketSystemDatabaseSettings.Value.UserCollectionName);
        }
        public async Task<User> GetUserByUsernameAndpassword(string username, string password)
        {
            return await _userCollection.Find(x => x.Email == username && x.Password == password).FirstOrDefaultAsync();
        }
    }
}
